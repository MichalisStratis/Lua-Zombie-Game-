function love.load()

    math.randomseed(os.time())
    coreWidth=720
    coreHeight=960
    scale=1
    shiftdown=0

    osString = love.system.getOS()
    if osString == "Android" or osString == "iOS" then
        scale = love.graphics.getWidth()/coreWidth
        shiftdown = (love.graphics.getHeight() - (coreHeight * scale)) / 2 /scale
    else
        scale = 0.6
    end

    love.window.setMode(coreWidth * scale, coreHeight * scale)


    anim8=require 'libraries/anim8/anim8'
    wf = require "libraries/windfield/windfield"
    timer = require "libraries/hump/timer"
    lume = require "libraries/lume/lume"

    sounds = {}
  
    sounds.music=love.audio.newSource("sounds/ZombieMusic.mp3","stream")
    sounds.gun=love.audio.newSource("sounds/gun.mp3","stream")
    sounds.gun:setPitch(1.5)
    

    sounds.music:setLooping(true)
    sounds.music:play()

    sprites = {}
    sprites.background = love.graphics.newImage('sprites/background.png')
    sprites.playerSheet=love.graphics.newImage('sprites/playerSheet.png')
    sprites.zombie=love.graphics.newImage('sprites/zombie.png')
    
    local grid=anim8.newGrid(614,564,sprites.playerSheet:getWidth(),sprites.playerSheet:getHeight())

    animations={}
    animations.idle=anim8.newAnimation(grid('1-15',1),0.05)
    animation=animations.idle

     -- 0 is the main menu and 1 is the gameplay
     gamerun = 0
     kills = 0
     killp=0
     timer=0
     maxtime=2
     zombiespawntime=maxtime
     health=5
     besttime=0
     --bombtimer=10
     
     player={}
     player.x=coreWidth/2
     player.y=coreHeight/2

    
     zombies={}
 
    
 

     ------------FONT-----------------
     myfont=love.graphics.newFont(30)
     minifont=love.graphics.newFont(20)

    
end 

function love.update(dt)
    animations.idle:update(dt)
    if gamerun==1 then 
        if timer>=0 then 
            timer=timer+dt
        end 
        
        for i,z in ipairs(zombies) do 
            z.x=z.x+(math.cos(playerzombie(z))*z.speed*dt)
            z.y=z.y+(math.sin(playerzombie(z))*z.speed*dt)

            if distancebetween(z.x,z.y,player.x,player.y)<20 then 
                z.dead=true 
                health=health-1
            end   
        end
        for i=#zombies,1,-1 do 
            local z=zombies[i]
            if z.dead==true then
                table.remove(zombies,i)
            end
        end

        
        zombiespawntime=zombiespawntime-dt
        if zombiespawntime<=0 then 
            spawnZombie()
            maxtime=maxtime*0.97
            zombiespawntime=maxtime
        end

        if health<=0 then 
            gamerun=2
            if timer>besttime then 
                besttime=timer
            end 
            for i=#zombies,1,-1 do 
                local z=zombies[i]
                table.remove(zombies,i)
            end
        end 
    end
end 
------------------------------------------------------------------------------------------------------------------


function love.draw()
    -- Scaling all graphics
    love.graphics.scale(scale)

    love.graphics.draw(sprites.background, 0, 0,nil,2,2,1.5)
    if gamerun==0 then 
        love.graphics.setFont(minifont)
        love.graphics.print("Try to keep the boy unharmed as long as possible",coreWidth/5,coreHeight/2-50+shiftdown)
        love.graphics.print("Touch the screen to start the game",coreWidth/5+45,coreHeight/2+shiftdown)
        

    end 
    if gamerun==1 then 
       
        animation:draw(sprites.playerSheet,coreWidth/2,coreHeight/2+shiftdown,nil,0.2,0.2,130,300)
        love.graphics.setFont(myfont)
        love.graphics.print("Kills: "..kills,5,5)
        love.graphics.print("Health: "..health,coreWidth-150,5)

        love.graphics.print(math.ceil(timer),coreWidth/2,5)

        for i,z in ipairs(zombies) do 
            love.graphics.draw(sprites.zombie,z.x,z.y,playerzombie(z),nil,nil,sprites.zombie:getWidth()/2,sprites.zombie:getHeight()/2)
        end 
    end

    if gamerun==2 then 
        
        love.graphics.setFont(minifont)
        love.graphics.print("You manage to keep the boy alive for "..math.ceil(timer).." seconds",coreWidth/3-100,coreHeight/2-50+shiftdown)
        love.graphics.print("Touch the screen to play again",coreWidth/3-30,coreHeight/2+shiftdown)
        love.graphics.print("Longest time: "..math.ceil(besttime),coreWidth/10,coreHeight/10+shiftdown)
    end 
end 
-------------------------------------------------------------------------------------------------------------------
function love.mousepressed(x, y, button, istouch, presses )
    

    if gamerun==0 then 
        gamerun=1
    end
    
    if button==1 and gamerun==1 then 
        sounds.gun:play()
        for i,z in ipairs(zombies) do 

            local mousetotarget=distancebetween(z.x,z.y,x/scale,y/scale)
            if mousetotarget<z.radius then 
                kills=kills+1
                z.dead=true
                killp=killp+1
                if killp==5 then 
                    health=health+1
                    z.radius=z.radius+5
                    killp=0
                end

            end
        end

    end 
    
    if gamerun==2 then 
        gamerun=1
        kills=0
        timer=0
        maxtime=2
        health=5
    end
end    


function spawnZombie()
    local zombie={}
    zombie.x=math.random(5,coreWidth)
    zombie.y=math.random(5,coreHeight)
    zombie.speed=100
    zombie.dead=false
    zombie.radius=20

    local side=math.random(1,4)
    if side==1 then 
        zombie.x=-30
        zombie.y=math.random(0,coreHeight+shiftdown)
    

    elseif side==2 then 
        zombie.x=coreWidth+30
        zombie.y=math.random(0,coreHeight+shiftdown)
    

    elseif side==3 then 
        zombie.y=-30
        zombie.x=math.random(0,coreWidth)
    

    elseif side==4 then 
        zombie.y=coreHeight+30
        zombie.x=math.random(0,coreWidth)
    end



    table.insert(zombies,zombie)
end

 

function distancebetween(x1,y1,x2,y2)
    return math.sqrt((x2-x1)^2+(y2-y1)^2)
end  

function playerzombie(enemy)
    return math.atan2(player.y-enemy.y,player.x-enemy.x)
end     

-- function bomb()
    --local bombs={}
    --bomb.x=math.random(player.x-20,player.x+20)
    --bomb.y=math.random(player.y-20,player.y+20)
    --bomb.explode=false
    --bomb.radius=100
    --end 
